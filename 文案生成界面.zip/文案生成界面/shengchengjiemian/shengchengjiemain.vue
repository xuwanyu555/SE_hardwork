<template>
  <div class="container">
    <div class="header">
      <span class="back-arrow" @click="goBack">&#8592;</span>
      <h1>返回</h1>
    </div>
	<div class="lil_titel">生成文案示例</div>
    <div class="content-box">
      <div class="text-area">
        <p>“夕阳下的摩天轮，湖边的绿水映着光影，翻开书页的瞬间，仿佛时间也慢了下来。享受这片刻的宁静，感受生活的美好🌇📖 #福州慢生活 #惬意时光 #左海公园”</p>
      </div>
      <div class="image-area">
      </div>
    </div>
    <div class="button-group">
      <button @click="complete">完成</button>
      <button @click="regenerate">重新生成</button>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    goBack() {
      // 返回操作，例如使用 Vue Router
      this.$router.back();
    },
    complete() {
      // 完成操作
      console.log('完成');
    },
    regenerate() {
      // 重新生成文案
      console.log('重新生成');
    }
  }
};
</script>

<style scoped>
.container {
  padding: 20px;
}

.header {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.back-arrow {
  margin-right: 10px;
  cursor: pointer;
}

.lil_titel {
	margin-bottom: 20px;
}

h1 {
  margin: 0;
  font-size: 24px;
}

.content-box {
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 15px;
  margin-bottom: 20px;
}

.text-area {
  margin-bottom: 15px;
}

.image-area img {
  width: 100%;
  height: auto;
  margin-bottom: 10px;
}

.button-group {
  display: flex;
  justify-content: space-between;
}

button {
  padding: 10px 20px;
  border: none;
  background-color: #007bff;
  color: white;
  cursor: pointer;
  border-radius: 4px;
}

button:hover {
  background-color: #0056b3;
}
</style>
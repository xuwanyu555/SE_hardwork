<template>
  <div class="container">
	<span class="back">&#8592</span>
    <h1>文案生成</h1>
    <form id="platformForm" @submit.prevent="generateCopy">
      <label for="platformSelect">请选择自媒体平台:</label>
      <select id="platformSelect" v-model="selectedPlatform" name="platform">
        <option value="bilibili">Bilibili</option>
        <option value="xiaohongshu">小红书</option>
        <option value="douyin">抖音</option>
        <option value="custom">自定义</option>
      </select>
	  <div class="input_field">
      <input type="file" id="imageUpload" @change="onFileChange" accept="image/*" />
	  </div>
	  
      <button type="submit">生成文案</button>
    </form>
    <div id="copyOutput" v-html="copyOutputHtml"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectedPlatform: 'bilibili',
      copyOutputHtml: '',
      imageSrc: ''
    };
  },
  methods: {
    onFileChange(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.imageSrc = e.target.result;
        };
        reader.readAsDataURL(file);
      }
    },
    generateCopy() {
      let copyText = '';
      if (this.imageSrc) {
        const imgElement = `<img src="${this.imageSrc}" style="max-width: 100%; height: auto; display: block; margin-bottom: 10px;" />`;
        this.copyOutputHtml = imgElement;
      }

      switch (this.selectedPlatform) {
        case 'bilibili':
          copyText = '这里是Bilibili平台的文案内容。';
          break;
        case 'xiaohongshu':
          copyText = '这里是小红书平台的文案内容。';
          break;
        case 'douyin':
          copyText = '这里是抖音平台的文案内容。';
          break;
        case 'custom':
          copyText = '这里是自定义平台的文案内容，已上传图片。';
          break;
        default:
          copyText = '请选择一个平台。';
      }

      this.copyOutputHtml += copyText;
    }
  }
};
</script>

<style scoped>
body {
  font-family: Arial, sans-serif;
  background-color: #ffffff;
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.container {
	background: #ffffff;
	padding: 100px 200px;
	border-radius: 8px;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	text-align: center;
}

h1 {
	margin-bottom: 80px;
	text-align: left;
	margin-right: 50px;
	border-bottom: 1px solid #000000;
	background-color: #55aaff; 
	padding: 10px;
	font-size: 24px;
	color: #333;
	font-weight: bold;
	font-family: 'Arial', sans-serif;
	text-transform: uppercase;

}

form {
  margin-bottom: 200px;
}

label {
  margin-right: 10px;
  margin-bottom: 100px;
}

select {
  padding: 5px;
  margin-right: 20px;
}

.input_field {
	width: 250px;
	height: 300px;
	background-color: #ccc;
	border: 1px solid #333;
	border-radius: 2px;
	margin-top: 50px;
	margin-bottom: 50px;
}
input[type="file"] {
  margin: 10px 0;
  padding: 150px 25px;
  border: 1px solid #ffffff;
  border-radius: 4px;
  background-color: #ffffff;
}

input[type="file"]::file-selector-button {
  border: none;
  margin-top: 20px;
  border-radius: 4px;
  padding: 5px 15px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

input[type="file"]::file-selector-button:hover {
  background-color: #0056b3;
}

button {
  margin-top: 20px;
  padding: 1px 1px;
  color: #000000;
  background-color: #55aaff;
  cursor: pointer;
}

</style>
'use strict';
const db = uniCloud.database();  // 获取数据库实例
const usersCollection = db.collection('users');  // 获取'users'集合

// 用于校验验证码的模拟
// 请替换为你实际的验证码存储与验证逻辑
const storedVerificationCode = '202411';  // 假设你存储了验证码

exports.main = async (event, context) => {
  const { phone, verificationCode, password,nickname } = event;  // 获取前端传递的参数 
  // 1. 校验验证码
  if (verificationCode !== storedVerificationCode) {
    return { status: 'error', message: '验证码错误' };
  }
  // 2. 检查手机号是否已注册
  const user = await usersCollection.where({ phone }).get();  // 查询手机号是否存在
  if (user.data.length > 0) {
    return { status: 'error', message: '该手机号已注册' };
  }
  const usernc = await usersCollection.where({ nickname }).get();  // 查询手机号是否存在
  if (usernc.data.length > 0) {
    return { status: 'error', message: '该昵称已使用' };
  }
  try {
    // 3. 将用户信息插入数据库
    const result = await usersCollection.add({
      phone,
      password,  // 存储加密后的密码
	  nickname,
    });
    // 返回注册成功的响应
    return { status: 'success', message: '注册成功' };
  } catch (error) {
    console.error('注册失败', error);
    return { status: 'error', message: '注册失败，请重试' };
  }
};
// 'use strict';
// const db = uniCloud.database();

// exports.main = async (event, context) => {
//   // 获取客户端传递的数据
//   const { phone, verificationCode, password } = event;

//   // 插入数据到云数据库
//   let res = await db.collection("users").add({
//     phone,
//     password: hashedPassword,  // 存储加密后的密码
//     createdAt: new Date()
//   });

//   // 返回结果给客户端
//   return res;
// };

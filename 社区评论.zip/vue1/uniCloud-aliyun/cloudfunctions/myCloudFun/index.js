'use strict';
const db = uniCloud.database();

exports.main = async (event, context) => {
  // 获取客户端传递的数据
  const { title, content, images, location } = event;

  // 插入数据到云数据库
  let res = await db.collection("post").add({
    title,
    content,
    images,     // 图片文件ID数组
    location,   // 定位信息（详细地址）
    createTime: new Date()
  });

  // 返回结果给客户端
  return res;
};

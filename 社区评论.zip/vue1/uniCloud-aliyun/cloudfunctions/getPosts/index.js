// 云函数：getPosts.js
'use strict';
const db = uniCloud.database();
exports.main = async (event, context) => {
  try {
    // 从数据库中获取所有帖子内容
    const res = await db.collection('post').get();
    return res;
  } catch (error) {
    return { code: 500, message: '获取帖子失败', error };
  }
};

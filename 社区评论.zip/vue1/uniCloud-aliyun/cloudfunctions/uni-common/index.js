'use strict'; 

const db = uniCloud.database();

exports.main = async (event, context) => {
  console.log('Received event:', JSON.stringify(event, null, 2)); // 详细打印请求事件

  const { action, data } = event;

  if (action === 'fetchPosts') {
    
    try {
      const postsCollection = db.collection('post');
	  const commentsCollection = db.collection('comments');
      const postsResult = await postsCollection.get();
      
      if (postsResult.affectedDocs > 0) {
		const posts = await Promise.all(
		        postsResult.data.map(async (post) => {
		          // 获取与该帖子相关的评论
		          const commentsResult = await commentsCollection.where({ postID: post._id }).get();
				  //const postCollection =await postsCollection.where({posptID:post._id}).get();
		          post.comments = commentsResult.data || [];
				  //post.content=postsCollection.
		          post.images = post.images || [];
				  post.username = postsResult.username || '匿名用户';
				  post.location = postsResult.location || '';
				  post.userAvatar = postsResult.userAvatar || '';
		          return post;
		        })
		      );
        return {
          code: 0,
          data: posts
        };
      } else {
        return {
          code: 1,
          msg: '未找到任何帖子数据'
        };
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
      return {
        code: 1,
        msg: '获取帖子数据失败'
      };
    }

  } else if (action === 'addComment') {
    // 向数据库添加评论
    const { postID, author, content } = data;
    console.log('Adding comment:', { postID, author, content });

    try {
      const commentsCollection = db.collection('comments');
      const result = await commentsCollection.add({
        postID,
        author,
        content,
        createdAt: new Date()
      });

      console.log('Comment added successfully:', result);
      return {
        code: 0,
        data: {
          _id: result.id,
          postID,
          author,
          content
        },
        msg: '评论添加成功'
      };
    } catch (error) {
      console.error('Error adding comment:', error);
      return {
        code: 1,
        msg: '添加评论失败'
      };
    }

  } else if (action === 'fetchPostDetails') {
    // 根据 postID 获取特定帖子的详细内容和评论
    const postID = data.postID;

    try {
      const postsCollection = db.collection('post');
      const commentsCollection = db.collection('comments');
      
      // 获取帖子数据
      const postResult = await postsCollection.doc(postID).get();
      
      if (postResult.data && postResult.data.length > 0) {
        const post = postResult.data[0];
        
        // 获取与该帖子相关的评论
        const commentsResult = await commentsCollection.where({ postID }).get();
        
        // 将评论添加到帖子数据中
        post.comments = commentsResult.data || [];
        post.username = postResult.username || '匿名用户';
        post.location = postResult.location || '';
        post.userAvatar = postResult.userAvatar || '';
        console.log('Returning post details:', JSON.stringify(post, null, 2));
        return {
          code: 0,
          data: post // 返回指定帖子的详细内容和评论
        };
      } else {
        console.log('Post not found for postID:', postID);
        return {
          code: 1,
          msg: '未找到指定的帖子'
        };
      }
    } catch (error) {
      console.error('Error fetching post details:', error);
      return {
        code: 1,
        msg: '获取帖子详细信息失败'
      };
    }
  } else {
    console.log('Unknown action:', action);
    return {
      code: 1,
      msg: '未知的操作'
    };
  }
};
'use strict';
const db = uniCloud.database();

exports.main = async (event, context) => {
  const { phone, password } = event;
  try {
    const user = await db.collection('users').where({
      phone,
      password
    }).get();
    if (user.data.length > 0) {
      return {
        status: 'success',
        message: '登录成功'
      };
    } else {
      return {
        status: 'error',
        message: '用户名或密码错误'
      };
    }
  } catch (error) {
    return {
      status: 'error',
      message: error.message
    };
  }
};
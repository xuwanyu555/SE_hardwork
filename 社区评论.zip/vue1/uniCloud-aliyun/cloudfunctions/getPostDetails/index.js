'use strict';
const db = uniCloud.database();

exports.main = async (event, context) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  const { data, action } = event;
  const postsCollection = db.collection('post');
  const commentsCollection = db.collection('comments');

  // 检查是否是添加评论请求
  if (action === 'addComment') {
    const { postID, author, content } = data;
    console.log('Adding comment:', { postID, author, content });

    try {
      const result = await commentsCollection.add({
        postID,
        author,
        content,
        createdAt: new Date()
      });
      console.log('Comment added successfully:', result);
      return {
        code: 0,
        data: {
          _id: result.id,
          postID,
          author,
          content
        },
        msg: '评论添加成功'
      };
    } catch (error) {
      console.error('Error adding comment:', error);
      return {
        code: 500,
        msg: '添加评论失败',
        error
      };
    }
  } else {
    // 否则直接返回帖子详情
    const { _id } = data; // 获取帖子 ID
    try {
      const postSnapshot = await postsCollection.doc(_id).get();
      console.log('Post data fetched:', postSnapshot);

      if (postSnapshot.data && postSnapshot.data.length > 0) {
        const post = postSnapshot.data[0];
        const commentsResult = await commentsCollection.where({ postID: _id }).get();
        post.comments = commentsResult.data || [];
        
        return {
          code: 0,
          data: post
        };
      } else {
        return {
          code: 1,
          msg: '未找到指定的帖子'
        };
      }
    } catch (error) {
      console.error('Error fetching post details:', error);
      return {
        code: 500,
        msg: '获取帖子失败',
        error
      };
    }
  }
};

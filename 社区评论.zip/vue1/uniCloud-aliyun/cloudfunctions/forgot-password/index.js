'use strict';
const db = uniCloud.database();  // 获取数据库实例
const usersCollection = db.collection('users');  // 获取 'users' 集合

// 用于校验验证码的模拟
const storedVerificationCode = '202411';  // 假设你存储了验证码

exports.main = async (event, context) => {
  const { phone, verificationCode, newPassword } = event;  // 获取前端传递的参数

  // 1. 校验验证码
  if (verificationCode !== storedVerificationCode) {
    return { status: 'error', message: '验证码错误' };
  }

  // 2. 检查手机号是否已注册
  const user = await usersCollection.where({ phone }).get();  // 查询手机号是否存在
  if (user.data.length === 0) {
    return { status: 'error', message: '该手机号未注册' };
  }

  try {
    // 3. 更新用户密码
    const result = await usersCollection.doc(user.data[0]._id).update({
      password: newPassword,  // 存储新密码，实际应用中应进行加密处理
    });

    // 返回更新成功的响应
    return { status: 'success', message: '密码重置成功' };
  } catch (error) {
    console.error('密码重置失败', error);
    return { status: 'error', message: '密码重置失败，请重试' };
  }
};
<template>
  <view>
    <view v-for="post in posts" :key="post._id" class="post">
      <text>{{ post.title }}</text>
      <!-- 评论列表 -->
      <view v-for="comment in post.comments" :key="comment._id" class="comment">
        <text>{{ comment.author }}: {{ comment.content }}</text>
      </view>
      <!-- 评论输入框 -->
      <input v-model="newComment[post._id]" placeholder="添加评论" />
      <button @click="addComment(post._id)">提交评论</button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      posts: [],
      newComment: {},
    };
  },
  methods: {
    async fetchPosts() {
      try {
        const res = await uniCloud.callFunction({
          name: 'uni-common',
          data: {
            action: 'fetchPosts', // 假设你有获取帖子数据的action
          },
        });
        if (res.result.code === 0) {
          this.posts = res.result.data;
        }
      } catch (error) {
        console.error('Error fetching posts:', error);
      }
    },
    async addComment(postID) {
      const content = this.newComment[postID];
      if (!content) return uni.showToast({ title: '请输入评论内容', icon: 'none' });

      try {
        const res = await uniCloud.callFunction({
          name: 'uni-common',
          data: {
            action: 'addComment',
            data: {
              postID: postID,
              author: '当前用户', // 替换为实际的用户名
              content: content,
            },
          },
        });
        if (res.result.code === 0) {
          uni.showToast({ title: '评论成功', icon: 'success' });
          this.newComment[postID] = ''; // 清空评论框
          this.fetchPosts(); // 刷新帖子和评论
        } else {
          uni.showToast({ title: res.result.msg, icon: 'none' });
        }
      } catch (error) {
        console.error('Error adding comment:', error);
      }
    },
  },
  onLoad() {
    this.fetchPosts();
  },
};
</script>

<style scoped>
/* 样式代码 */
.post {
  margin-bottom: 20px;
}
.comment {
  margin-left: 10px;
  color: #666;
}
</style>

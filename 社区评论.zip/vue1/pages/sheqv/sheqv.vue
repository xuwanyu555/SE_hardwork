<template>
  <view class="container">
    <!-- 顶部导航栏 -->
    <view class="top-bar">
      
      <view class="tabs">
        <text v-for="tab in tabs" :key="tab" :class="{ active: selectedTab === tab }" @click="selectTab(tab)">
          {{ tab }}
        </text>
		
      </view>
	  <!-- 右上角加号按钮，点击跳转到发布帖子页面 -->
	  <button @click="goToPublishPage" class="plus-button">＋</button>
    </view>

    

    <!-- 旅游区域卡片 -->
    <view class="tourist-areas">
      <view v-for="area in touristAreas" :key="area.id" class="tourist-card">
        <image :src="area.image" class="tourist-image" />
        <text class="tourist-name">{{ area.name }}</text>
      </view>
    </view>

    <!-- 帖子列表 -->
    <view v-for="post in posts" :key="post._id" class="post" @click="goToPostDetail(post._id)">
      <view class="post-header">
        <image :src="post.userAvatar" class="post-avatar"/>
        <text class="post-username">{{ post.username }}</text>
      </view>
	  <view class="post-title">
	  	<text>{{post.title}}</text>
	  </view>
      <view class="post-content">
        <text>{{ post.content }}</text>
        <image v-for="img in post.images" :key="img" :src="img" class="post-image"/>
      </view>
      <view class="post-actions">
        <text>评论</text>
        <text>喜欢</text>
        <text>{{ post.location }}</text>
      </view>
    </view>

    
  </view>
</template>

<script>
export default {
  data() {
    return {
      tabs: ['推荐', '关注', '好友', '福州'],
      selectedTab: '推荐',
      recommendedUsers: [
        { id: 1, avatar: 'https://mp-d5212e7b-c316-435b-888f-aba1077c11a3.cdn.bspapp.com/userAvatar/userAvatar_1.jpg' },
        { id: 2, avatar: 'https://mp-d5212e7b-c316-435b-888f-aba1077c11a3.cdn.bspapp.com/userAvatar/userAvatar_2.jpg' },
        // 其他推荐用户
      ],
      touristAreas: [
        { id: 1, name: '广州长隆旅游度假区', image: 'https://mp-d5212e7b-c316-435b-888f-aba1077c11a3.cdn.bspapp.com/cloudstorage/a51364e8-ac23-4d8c-b380-3a8e835e9877.png' },
        { id: 2, name: '三亚旅游度假区', image: 'https://mp-d5212e7b-c316-435b-888f-aba1077c11a3.cdn.bspapp.com/cloudstorage/a102e1b2-fd08-4525-b915-f6918e1d9f0d.png' },
        { id: 3, name: '平潭旅游度假区', image: 'https://mp-d5212e7b-c316-435b-888f-aba1077c11a3.cdn.bspapp.com/cloudstorage/c91374b3-9d98-4f03-807e-24d606cf829b.png' },
        { id: 4, name: '哈尔滨旅游度假区', image: 'https://mp-d5212e7b-c316-435b-888f-aba1077c11a3.cdn.bspapp.com/cloudstorage/VCG211374911672.jpg' },
        
		// 其他旅游区域
      ],
      posts: []  // 用于存储从云数据库获取的帖子数据
    };
  },
  methods: {
    async fetchPosts() {
      try {
        // 调用云函数获取帖子
        const res = await uniCloud.callFunction({
          name: 'getPosts'
        });
        if (res.result && res.result.data) {
          this.posts = res.result.data;
        } else {
          uni.showToast({
            title: '获取帖子失败',
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('获取帖子失败', error);
        uni.showToast({
          title: '网络错误',
          icon: 'none'
        });
      }
    },
    selectTab(tab) {
      this.selectedTab = tab;
      // 可以在此处添加不同标签的逻辑
    },
	goToPublishPage() {
	  uni.navigateTo({
	    url: "/pages/publish/publish",
	  });
	},
	
	goToPostDetail(postId) {
	    uni.navigateTo({
	      url: `/pages/PostDetail/PostDetail?id=${postId}`  // 跳转到帖子详情页面
	    });
	  }
  },
  onLoad() {
    this.fetchPosts(); // 页面加载时获取帖子
  }
};
</script>

<style>
.container {
  padding: 10px;
}

.plus-button {
  display: flex;                    /* 使用Flexbox来对齐按钮中的内容 */
  justify-content: center;          /* 水平居中 */
  align-items: center;              /* 垂直居中 */
  width: 40px;                      /* 按钮的宽度 */
  height: 40px;                     /* 按钮的高度 */
  background-color: #007AFF;        /* 按钮的背景色 */
  border-radius: 50%;               /* 圆形按钮 */
  color: white;                     /* 字体颜色为白色 */
  font-size: 32px;                  /* 加号字体大小 */
  font-weight: bold;                /* 字体加粗 */
  cursor: pointer;                 /* 鼠标悬停时显示指针 */
  transition: all 0.3s ease;        /* 按钮点击时的平滑过渡效果 */
  border: none;                     /* 去掉默认边框 */
}

.plus-button:hover {
  background-color: #005bb5;        /* 鼠标悬停时改变背景色 */
  transform: scale(1.1);             /* 鼠标悬停时放大按钮 */
}

.plus-button:active {
  background-color: #004aad;        /* 按钮点击时背景色变深 */
  transform: scale(1);               /* 点击时恢复原始大小 */
}


.top-bar {
  display: flex;
  justify-content: space-between;
  padding: 5px;
}

.city-selector {
  display: flex;
  align-items: center;
}

.dropdown-icon {
  margin-left: 4px;
}

.tabs {
  display: flex;                  /* 使用Flexbox布局 */
  justify-content: center;        /* 水平居中 */
  align-items: center;            /* 垂直居中（如果父容器有高度的话） */
  width: 100%;                    /* 容器宽度100%，如果需要固定宽度可以设置具体值 */
  height: 40px;                   /* 给tabs容器设置固定高度，如果需要的话 */
}

.tabs text {
  margin: 0 15px;                 /* 为每个tab增加左右间距，避免它们挤在一起 */
  cursor: pointer;               /* 鼠标悬停时显示指针 */
}

.tabs text.active {
  font-weight: bold;              /* 为选中的tab加粗 */
  color: #007AFF;                 /* 修改选中的tab颜色 */
}


.active {
  color: #000;
  font-weight: bold;
}

.recommend-users {
  display: flex;
  padding: 10px 0;
}

.user-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
}

.tourist-areas {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 10px 0;
}

.tourist-card {
  width: 48%;
  margin-bottom: 10px;
}

.tourist-image {
  width: 100%;
  height: 100px;
  border-radius: 8px;
}

.tourist-name {
  text-align: center;
  margin-top: 5px;
}

.post {
  margin-top: 15px;
  padding: 10px;
  background-color: #f9f9f9;
  border-radius: 8px;
}

.post-header {
  display: flex;
  align-items: center;
}

.post-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
}

.post-username {
  font-weight: bold;
}

.post-title {
  margin-top: 12px;
  font-weight: 600;
}

.post-content {
  margin-top: 10px;
}

.post-image {
  width: 100%;
  height: 200px;
  margin-top: 10px;
  border-radius: 8px;
}

.post-actions {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.bottom-nav {
  position: fixed;
  bottom: 0;
  width: 100%;
  display: flex;
  justify-content: space-around;
  padding: 10px 0;
  background-color: #fff;
}
</style>
